import React from 'react';


const Card = ({ title, imgSrc, rating, releaseDate }) => {
  return (
    <div className="movie-card">
      <img src={imgSrc} alt={title} className="movie-poster" />
      <h2 className="movie-title">{title}</h2>
      <p className="movie-release-date">Released: {releaseDate}</p>
      <div className="movie-rating">
      <i class="ri-star-fill"></i>
        <span>{rating}</span>
      </div>
    </div>
  );
};

export default Card;
