import React from 'react'
import './Navbar.css'
function Navbar() {
  return (
    <>
        <div className='flex justify-between items-center py-2 px-10 text-black border-b border-gray-200'>
            <div className='flex items-center gap-4'>
            <img src="/src/assets/logo.webp" alt="logo" className="h-20 w-auto" />
            
                <nav className="flex gap-4">
                    <a href="/" className="text-black font-medium hover:text-gray-700 transition-colors">Home</a>
                    <a href="/genre" className="text-black font-medium hover:text-gray-700 transition-colors">Genre</a>
                </nav>
            
            </div>
            <div className='flex items-center gap-2'>
            <i id="search-icon" class="ri-search-line"></i>
             <input type="text" placeholder="Search latest movies..." class="p-2 border rounded
focus:outline-none focus:ring-2 focus:ring-black w-full text-black bg-white"/>
            </div>
        </div>
        
    </>
  )
}

export default Navbar
