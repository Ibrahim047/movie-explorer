import axios from 'axios';

const API_KEY = '80a6b553';
const BASE_URL = 'https://www.omdbapi.com';

export const fetchMovies = async ({ searchTerm = '', page = 1 }) => {
  try {
    const response = await axios.get(BASE_URL, {
      params: {
        apikey: API_KEY,
        s: searchTerm || 'guardians',
        page,
        type: 'movie'
      }
    });
    
    if (response.data.Response === "True") {
      return {
        results: response.data.Search,
        totalResults: Number(response.data.totalResults),
        page,
      };
    } else {
      throw new Error(response.data.Error || 'No movies found');
    }
  } catch (error) {
    console.error('API Error:', error);
    throw new Error(error.response?.data?.Error || error.message || 'Failed to fetch movies');
  }
};

export const fetchMovieDetails = async (imdbID) => {
  try {
    const response = await axios.get(BASE_URL, {
      params: {
        apikey: API_KEY,
        i: imdbID,
        plot: 'full'
      }
    });
    
    if (response.data.Response === "True") {
      return response.data;
    } else {
      throw new Error(response.data.Error || 'Movie not found');
    }
  } catch (error) {
    console.error('API Error:', error);
    throw new Error(error.response?.data?.Error || 'Failed to fetch movie details');
  }
};