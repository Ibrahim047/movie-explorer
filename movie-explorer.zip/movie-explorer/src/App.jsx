import React from 'react'
import Navbar from './Components/Navbar/Navbar'
import Card from './Components/Card/Card'

function App() {
  const moviesData = [
    {
      title: "Inception",
      imgSrc: "https://m.media-amazon.com/images/M/MV5BMjAxMzY3NjcxNF5BMl5BanBnXkFtZTcwNTI5OTM0Mw@@._V1_SX300.jpg",
      rating: "8.8",
      releaseDate: "16 Jul 2010"
    },
    {
      title: "The Matrix",
      imgSrc: "https://m.media-amazon.com/images/M/MV5BNzQzOTk3OTAtNDQ0Zi00ZTVkLWI0MTEtMDllZjNkYzNjNTc4L2ltYWdlXkEyXkFqcGdeQXVyNjU0OTQ0OTY@._V1_SX300.jpg",
      rating: "8.7",
      releaseDate: "31 Mar 1999"
    },
    // Add more movie objects here as needed
  ];

  return (
    <div>
      <Navbar />
      <div className="movie-container">
        {moviesData.map((movie, index) => (
          <Card 
            key={index}
            title={movie.title}
            imgSrc={movie.imgSrc}
            rating={movie.rating}
            releaseDate={movie.releaseDate}
          />
        ))}
      </div>
    </div>
  )
}

export default App
